# Airway Motel Admin System — Project Setup

Set up the complete React + Vite + Supabase project with an organized folder structure, all necessary packages installed, and configuration files ready — **no application code yet**, just the scaffolding.

## What We're Building (Context)

A full-scale admin management system for Airway Motel that digitizes the entire manual check-in/checkout workflow:

- **Admin-only** (no guest-facing website for now)
- **Cross-device handoff** via QR code for ID photo capture + guest signature on phone/iPad
- **Supabase** for database, auth, file storage, and real-time sync
- **React + Vite** for the frontend

---

## Proposed Folder Structure

```
airway-motel/
├── public/
│   └── favicon.svg
│
├── src/
│   ├── main.jsx                    # App entry point
│   ├── App.jsx                     # Root component with router
│   ├── index.css                   # Global styles & CSS variables
│   │
│   ├── config/
│   │   └── supabase.js             # Supabase client initialization
│   │
│   ├── hooks/                      # Custom React hooks
│   │   └── .gitkeep
│   │
│   ├── context/                    # React context providers
│   │   └── .gitkeep
│   │
│   ├── stores/                     # Zustand state management
│   │   └── .gitkeep
│   │
│   ├── lib/                        # Utility functions & helpers
│   │   └── .gitkeep
│   │
│   ├── services/                   # Supabase API calls (one file per table)
│   │   └── .gitkeep
│   │
│   ├── components/                 # Reusable UI components
│   │   ├── ui/                     # Primitives (Button, Input, Modal, Card, etc.)
│   │   │   └── .gitkeep
│   │   ├── layout/                 # Sidebar, Header, PageWrapper
│   │   │   └── .gitkeep
│   │   ├── rooms/                  # Room-specific components (RoomCard, RoomGrid)
│   │   │   └── .gitkeep
│   │   ├── guests/                 # Guest-specific components (GuestForm, IDPreview)
│   │   │   └── .gitkeep
│   │   ├── checkin/                # Check-in flow components (StepWizard, SignaturePad)
│   │   │   └── .gitkeep
│   │   ├── checkout/               # Checkout flow components (ReceiptPreview, LateFeeCalc)
│   │   │   └── .gitkeep
│   │   └── scan/                   # QR code + mobile handoff components
│   │       └── .gitkeep
│   │
│   ├── pages/                      # Full page components (one per route)
│   │   ├── LoginPage.jsx
│   │   ├── DashboardPage.jsx
│   │   ├── CheckInPage.jsx
│   │   ├── RoomStatusPage.jsx
│   │   ├── CheckoutPage.jsx
│   │   ├── GuestHistoryPage.jsx
│   │   ├── SettingsPage.jsx
│   │   └── MobileScanPage.jsx      # The page opened via QR code on phone
│   │
│   └── assets/                     # Static assets (images, fonts, etc.)
│       └── .gitkeep
│
├── .env.example                    # Template for environment variables
├── .env                            # Actual env vars (git-ignored)
├── .gitignore
├── index.html                      # Vite entry HTML
├── package.json
├── vite.config.js
├── eslint.config.js
└── README.md
```

### Why This Structure?

| Directory | Purpose |
|---|---|
| `config/` | Single source of truth for Supabase client and any future configs |
| `hooks/` | Custom hooks like `useAuth`, `useRealtime`, `useRooms` — keeps logic out of components |
| `context/` | React context for auth state, theme, etc. |
| `stores/` | Zustand stores for global state (current check-in session, notifications) |
| `lib/` | Pure utility functions: date formatting, price calculations, late fee logic |
| `services/` | All Supabase queries grouped by table (`roomService.js`, `guestService.js`, etc.) |
| `components/` | Split by feature area so each domain has its own folder |
| `pages/` | One file per route — thin wrappers that compose components |
| `assets/` | Images, logos, fonts |

---

## Packages to Install

### Core
| Package | Why |
|---|---|
| `react` + `react-dom` | UI framework (included by Vite template) |
| `react-router-dom` | Client-side routing between pages |
| `@supabase/supabase-js` | Supabase client for database, auth, storage, realtime |

### Forms & Validation
| Package | Why |
|---|---|
| `react-hook-form` | Performant form handling with minimal re-renders |
| `zod` | Schema validation for form data (pairs with react-hook-form) |
| `@hookform/resolvers` | Connects zod schemas to react-hook-form |

### UI & UX
| Package | Why |
|---|---|
| `lucide-react` | Modern, clean icon set (consistent with a premium look) |
| `sonner` | Beautiful toast notifications (lightweight, great defaults) |
| `clsx` | Utility for conditional CSS class merging |

### Feature-Specific
| Package | Why |
|---|---|
| `react-signature-canvas` | Signature pad for guest signatures (touch + mouse) |
| `qrcode.react` | Generate QR codes for cross-device handoff |
| `date-fns` | Date manipulation (checkout time, late fees, formatting) |
| `jspdf` | Generate PDF receipts on the fly |
| `html2canvas` | Capture HTML elements as images (for receipt PDF generation) |

### State Management
| Package | Why |
|---|---|
| `zustand` | Lightweight global state (active session, auth state, etc.) |

### Dev Dependencies
| Package | Why |
|---|---|
| `eslint` | Code linting (included by Vite template) |
| `@types/react` | TypeScript types for intellisense (included by Vite) |

---

## Configuration Files

### `.env.example`
```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### `vite.config.js`
- Standard React plugin
- Path alias `@/` → `src/` for clean imports

---

## Open Questions

> [!IMPORTANT]
> **Supabase Project**: You mentioned you'll create the Supabase database yourself. Once you have the project URL and anon key, drop them into the `.env` file. Do you want me to also provide the SQL migration scripts for the database tables (`rooms`, `guests`, `stays`, `signatures`, `payments`)?

> [!IMPORTANT]
> **Room Count**: How many rooms does Airway Motel have? I need to know for seeding the rooms table and building the room grid layout.

> [!IMPORTANT]
> **Terms & Conditions Text**: From the photos, I can see the 10-point terms and conditions document. Should I hardcode that exact text into the app, or would the admin want to edit it from Settings later?

> [!IMPORTANT]
> **Pricing**: From the form I see "Daily/Weekly Rate" — are there different rate structures (daily vs. weekly)? Or is it just a nightly rate for 1-bed and 2-bed rooms?

---

## Verification Plan

### Automated Tests
```bash
npm run dev          # Vite dev server starts without errors
npm run build        # Production build compiles successfully
npm run lint         # No ESLint errors
```

### Manual Verification
- All folders exist with correct structure
- All packages in `package.json` with correct versions
- `.env.example` present, `.env` git-ignored
- Path alias `@/` resolves correctly
- Supabase client file connects (once you provide credentials)
- Dev server runs and shows a blank starter page
